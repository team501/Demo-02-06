import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Grid from '@material-ui/core/Grid';
import Assigned from './ChuteStatus/Assigned';
import AssignedPer from './ChuteStatus/AssignedPer';
import NotAssigned from './ChuteStatus/NotAssigned';
import Legends from './ChuteStatus/Legends';
import {Doughnut} from 'react-chartjs-2';

import './ChuteStatus/land.css';
import './ChuteStatus/label.css';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import {baseURL} from '../../services/Config';
import axios from 'axios';

const mainGrid = {
    padding: '15px',
    height: '280px',
};


export default class ChuteStatusOverview extends Component {
    constructor(props) {
		super(props);
		this.state = {  data: [],
						label: ['Full', 'Empty', 'Error', 'Disabled'],
						color: ['#d0021b', '#7ed321', '#f8e71c', '#9f9c9c'],
					    isLoading:true
					  };
	}
	
    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	getRecentOrders() {
		axios.get(baseURL+'chutesummary/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
		.then(res => {
			let chuteData = {  labels: this.state.label,
						  	   datasets: [{ data: [res.data.chuteFull, res.data.empty,
							  				  	   res.data.error, res.data.disabled],
							  				backgroundColor: this.state.color,
							  				hoverBackgroundColor: this.state.color
									}]
					   };
			this.setState({ data: res.data, chuteData:chuteData}); 
		}).catch(function (error) {
			console.log(error);
		});
	}
    
    render () {
            return(
				<div>
                <RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Chute Status"}
				fullBlock
				>
                    <Grid style={mainGrid} container>	
                        <Grid item xs={12} sm={6}>
                            <Doughnut data={this.state.chuteData} height={250} width={300} 
							  options={ { maintainAspectRatio: false, responsive: false,
						  		  legend: { display: false }
					  		   } } />  
                        </Grid>
                        <Grid item xs={12} sm={5}>
                            <Legends data={this.state.data}/>
                        </Grid>
						<div className="right-arrow-chute">
                            <Link to={{ pathname: '/app/dashboard/chuteStatus', state: { nextLink: this.props.nextLink } }}>
                                <i class="ti-angle-right"></i>
                            </Link>
                        </div>
                    </Grid>
                    
                    <Grid className="chute-bottom-grid" container>
                        <Grid item xs={4} sm={4}>
                            <Assigned value={this.state.data.assigned}/>
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <NotAssigned value={this.state.data.notassigned} />
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <AssignedPer value={this.state.data.assignedPercentage} />
                        </Grid>
                    </Grid>
            					 

                </RctCollapsibleCard>
				</div>
            );
    }
}