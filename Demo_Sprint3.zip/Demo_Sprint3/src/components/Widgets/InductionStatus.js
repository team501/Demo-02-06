/**
 * InductsForTheDay
 */
import React, { Component } from 'react';
import {Link} from 'react-router-dom'; 
//axios
import axios from 'axios';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';

//circular-progressbar
import CircularProgressbar from 'react-circular-progressbar';

//bar chart
import {Bar} from 'react-chartjs-2';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

class InductionStatus extends Component {
	constructor(props) {
		super(props);
		this.state = { data: [] };
	}
	
	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}
	
	getRecentOrders()  {
		axios.get(baseURL+'inductionstatusperhour/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    let label = new Array();
			    label.push("Peak");
			    label.push("Average");
			    label.push("Recric");
			    label.push("Minimum");
			    
			    let graphData = new Array();
			    graphData.push(res.data.peak);
			    graphData.push(res.data.average);
			    graphData.push(res.data.recric);
			    graphData.push(res.data.minimum);
			    
			    console.log("INDSPHR");
			    console.log(graphData);
			    console.log(label);
			    
			    let data = { labels: label,
						datasets: [ { 
							backgroundColor: [
								'rgba(126, 211, 33)',
								'rgba(126, 211, 33)',
								'rgba(248, 231, 28)',
								'rgba(208, 2, 27)'

								],
								borderColor: [
									'rgba(126, 211, 33)',
									'rgba(126, 211, 33)',
									'rgba(248, 231, 28)',
									'rgba(208, 2, 27)'

									],		  			
									borderWidth: 1,
									data: [ ...graphData, Math.min(...graphData) - (1)]
						}]
				};
			    
		        this.setState({ data: data});
		   }).catch(function (error) {
				console.log(error);
		  });
	}
	
	
	
	
	render() { 
	 return (
			<div>

				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Induction status per hour"}
				fullBlock
				>
                <div className="col-md-10 col-xl-10 col-sm-10 col-ls-10 float-left">  
								<Bar data={this.state.data} width={20} height={250} 
									options={{ maintainAspectRatio: false, legend: {
									display: false
								},scales: {
									xAxes: [{
										barPercentage: 0.1,
										ticks: {
											fontSize: 20
										},
										gridLines : {
								                display : false
								            } 
									}],
									yAxes: [{
										position: 'right',
										ticks: {
											fontSize: 20,
											fontWeight:800
										}
									}]}  }}/> 
						
							
				</div>
				<div class="right-arrow_induct">
					<Link to={{ pathname: '/app/dashboard/inductStatus', state: { nextLink: this.props.nextLink } }}>
						<i class="ti-angle-right"></i>
					</Link>
				</div>

					</RctCollapsibleCard>
					</div>
				);
		}
}

export default InductionStatus;
