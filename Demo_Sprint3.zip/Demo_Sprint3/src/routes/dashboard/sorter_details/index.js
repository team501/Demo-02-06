/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';


//Reloadable card
import {
	InductsForTheDayWidget,
	WaveStatusWidget,
	InductsForTheLastHourWidget,
	SortsForTheDayWidget,
	SortsForTheLastHourWidget,
	SortersWidget,
	WatchesWidget,
	InductionStatusWidget,
	ChuteStatusWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

//Chute Status Overview
import ChuteStatusOverview from 'Components/KPI/ChuteStatusOverview'; 

export default class SorterDetails extends Component {

	linkState = this.props.location.state === undefined ? '' : this.props.location.state.data; 

   	constructor(props) {
		super(props);
		this.state = { currentTime: {} };
	}

	//Starting cyclic-refresh.
	async componentDidMount() {		
		this.intervalID = setInterval( () => this.timeGenrator(), sessionStorage.getItem("refreshInterval") );
	}

	/*Refresh callback function,
	*responsible for generating time as props for child elements.*/
	async timeGenrator() {
		console.log(".....................................");
		this.setState({ currentTime: new Date().getTime() });
	}

	//Clearing previous interval on component unmount.
	componentWillUnmount() {
		clearInterval(this.intervalID);
	}

   render() {
      const { match } = this.props;
      return (
         <div className="ecom-dashboard-wrapper">
			<PageTitleBar 
				title={<IntlMessages id={this.linkState} />} 
				match={match}
				url="/app/dashboard/manageEquipment" 
				urlState={this.linkState}
			/>
            <div className="row row-no-margin">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-class-left">
					{/*Passing sorter routes for sorter id and current time.*/}
					<InductsForTheDayWidget currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} />
					<InductsForTheLastHourWidget currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} />
					<SortsForTheDayWidget currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} />
					<SortsForTheLastHourWidget currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} />
            	</div>
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right">
            		<WatchesWidget />
            		<InductionStatusWidget currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} nextLink={this.linkState} />
					<ChuteStatusOverview currentTime={this.state.currentTime} sorterRoute={'/' + this.linkState} nextLink={this.linkState} /> 
            	</div>
            </div>
         </div>
      )
   }
}


